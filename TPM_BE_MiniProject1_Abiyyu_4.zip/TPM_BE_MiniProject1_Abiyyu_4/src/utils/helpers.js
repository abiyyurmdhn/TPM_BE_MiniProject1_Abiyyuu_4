const calculateStress = (tugas, jam_tidur) =>
    tugas * 2 - jam_tidur;

module.exports = { calculateStress };