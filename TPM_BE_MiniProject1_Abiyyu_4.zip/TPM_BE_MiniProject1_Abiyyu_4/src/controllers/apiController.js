const fs = require('fs');
const path = './data/data.json';
const { calculateStress } = require('../utils/helpers');

module.exports.addStress = (req, res) => {
    const { tugas, jam_tidur } = req.body;

    const score = calculateStress(
        parseInt(tugas),
        parseInt(jam_tidur)
    );

    const newData = {
        tugas,
        jam_tidur,
        score
    };

    let data = JSON.parse(fs.readFileSync(path));
    data.records.push(newData);

    fs.writeFileSync(path, JSON.stringify(data, null, 2));

    res.redirect("/result");
};
