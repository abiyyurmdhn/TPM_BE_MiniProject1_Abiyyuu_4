const express = require('express');
const router = express.Router();
const fs = require('fs');
const dataPath = "data/data.json";

router.get("/", (req, res) => {
    res.render("home");
});

router.get("/input", (req, res) => {
    res.render("input");
});

router.get("/result", (req, res) => {
    const raw = fs.readFileSync(dataPath);
    const data = JSON.parse(raw);
    res.render("result", { data });
});

module.exports = router;